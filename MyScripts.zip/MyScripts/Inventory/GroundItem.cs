﻿using UnityEngine;
using System.Collections;

public class GroundItem : MonoBehaviour
{
    public Item item;

}
