﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(fileName = "Player Stats Class", menuName = "Prototype/Player Stats Class")]

public class PlayerStats : ScriptableObject
{
    public new readonly string name = "Default Class";

    public readonly int health = 100;
    public readonly int mana = 100;

    public readonly int strength = 5;
    public readonly int intelligence = 5;
    public readonly int defense = 5;
    public readonly int luck = 5;

}
