﻿using UnityEngine;
using System.Collections;

public class GunController : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}

public enum AmmoType
{
    Light,
    Medium,
    Heavy,
    Shell,
    Special
}
