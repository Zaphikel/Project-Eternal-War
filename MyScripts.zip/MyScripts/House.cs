﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class House : MonoBehaviour
{

    public GameObject roof;

    public GameObject[] windows;
    public GameObject[] doors;

    void Update()
    {
        
    }
}
